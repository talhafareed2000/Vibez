# Vibez

Music player allowing the user to choose a mp3 file from there directory and play it through our player.
